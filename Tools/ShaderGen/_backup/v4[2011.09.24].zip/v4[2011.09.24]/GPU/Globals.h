/*
=============================================================================
	File:	Globals.h
	Desc:	Global renderer constants (GPU constants manager).
=============================================================================
*/
#pragma once

#ifndef __MX_GLOBAL_SHADER_VARS_H__
#define __MX_GLOBAL_SHADER_VARS_H__



namespace GPU
{

	void UpdatePerFrameConstants( FLOAT globalTimeInSeconds );
	void UpdatePerViewConstants( const rxView& view );
	void UpdatePerObjectConstants( mat4_carg worldMatrix );

}//namespace GPU



#endif // !__MX_GLOBAL_SHADER_VARS_H__

//--------------------------------------------------------------//
//				End Of File.									//
//--------------------------------------------------------------//
