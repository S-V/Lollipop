/*
=============================================================================
	File:	Globals.cpp
	Desc:	Global renderer constants (GPU constants manager).
=============================================================================
*/

#include "Renderer_PCH.h"
#pragma hdrstop
#include "Renderer.h"

#include <Renderer/GPU/Main.hxx>
#include <Renderer/GPU/Globals.h>



namespace GPU
{

	void UpdatePerFrameConstants( FLOAT globalTimeInSeconds )
	{
		GPU::Shared_Globals::cb_PerFrame.globalTimeInSeconds = globalTimeInSeconds;
		GPU::Shared_Globals::cb_PerFrame.Update(D3DContext);

		GPU::Shared_Globals::Set(D3DContext);
	}

	void UpdatePerViewConstants( const rxView& view )
	{
		XMVECTOR	det;
		const float4x4	viewMatrix = view.CreateViewMatrix();
		const float4x4	projectionMatrix = view.CreateProjectionMatrix();
		const float4x4  viewProjectionMatrix = XMMatrixMultiply(viewMatrix,projectionMatrix);
		MX_OPTIMIZE("no need to calc full matrix inverse:");
		const float4x4	inverseViewMatrix = XMMatrixInverse(&det,viewMatrix);
		//const float4x4  invViewProjMatrix;
		//const float4x4  invViewProjTex2Clip;

		GPU::Shared_View::cb_PerView.viewMatrix = viewMatrix;
		GPU::Shared_View::cb_PerView.viewProjectionMatrix = viewProjectionMatrix;
		GPU::Shared_View::cb_PerView.inverseViewMatrix = inverseViewMatrix;
		GPU::Shared_View::cb_PerView.projectionMatrix = projectionMatrix;
		GPU::Shared_View::cb_PerView.inverseProjectionMatrix = XMMatrixInverse(&det,projectionMatrix);
		GPU::Shared_View::cb_PerView.Update(D3DContext);

		GPU::Shared_View::Set(D3DContext);
	}

	void UpdatePerObjectConstants( mat4_carg worldMatrix )
	{
		const float4x4	worldViewMatrix = XMMatrixMultiply(worldMatrix,GPU::Shared_View::cb_PerView.viewMatrix);
		const float4x4	worldViewProjectionMatrix = XMMatrixMultiply(worldMatrix,GPU::Shared_View::cb_PerView.viewProjectionMatrix);

		GPU::Shared_Object::cb_PerObject.worldMatrix = worldMatrix;
		GPU::Shared_Object::cb_PerObject.worldViewMatrix = worldViewMatrix;
		GPU::Shared_Object::cb_PerObject.worldViewProjectionMatrix = worldViewProjectionMatrix;
		GPU::Shared_Object::cb_PerObject.Update(D3DContext);

		GPU::Shared_Object::Set(D3DContext);
	}

}//namespace GPU



//--------------------------------------------------------------//
//				End Of File.									//
//--------------------------------------------------------------//
