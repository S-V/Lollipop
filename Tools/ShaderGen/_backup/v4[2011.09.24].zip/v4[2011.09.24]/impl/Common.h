
#pragma once

//---------------------------------------------------------------------------
//	Includes
//---------------------------------------------------------------------------

#include "ShaderGen.h"
using namespace ShaderGen;

#include <Base/Templates/Containers/BitSet/BitSet32.h>

#include <Base/Text/TextUtils.h>
#include "Base/Text/Parse_Util.h"
#include <Base/Text/TextBuffer.h>
#include <Base/Util/Sorting.h>

#define MAX_SAMPLER_STATE_SLOTS 16
#define MAX_SHADER_RESOURCE_SLOTS 16
#define MAX_CONSTANT_BUFFER_SLOTS 14

#include <Graphics/Graphics_DX11.h>
#include <Graphics/DX11/DX11Private.h>
//#include <Graphics/DX11/DX11Helpers.h>
//#pragma comment( lib, "Graphics.lib" )

//---------------------------------------------------------------------------
//	Forward declarations
//---------------------------------------------------------------------------

class Parser;

//---------------------------------------------------------------------------
//	Memory management
//---------------------------------------------------------------------------

void* Lex_Alloc( SizeT bytes );
void Lex_Free( void* ptr );

#define LEX_NEW( typeName )	new(Lex_Alloc(sizeof(typeName))) typeName

//---------------------------------------------------------------------------
//	Parsing
//---------------------------------------------------------------------------

enum
{
	MaxFileNameLength = 64,
	MaxIdentifierLength = 48,
	MaxInformationLength = 64,
	MaxTempStringLength = 128,
};

typedef TFixedString< MaxFileNameLength >		wrFile;
typedef TFixedString< MaxIdentifierLength >		wrName;
typedef TFixedString< MaxInformationLength >	wrInfoStr;
typedef TFixedString< MaxTempStringLength >		wrBuffer;

/*
-----------------------------------------------------------------------------
	wrLocation - represents the position of a token in a source file
-----------------------------------------------------------------------------
*/
struct wrLocation
{
	String	file;
	UINT	line, column;

public:
	wrLocation()
	{}
	wrLocation( const char* fileName, UINT lineNum, UINT colNum )
		: file(fileName), line(lineNum), column(colNum)
	{}
	wrBuffer ToStr() const
	{
		wrBuffer buf;
		buf.Format("%s(%u,%u)", file.ToChars(),line,column);
		return buf;
	}
};

// base class for parsed tokens
struct wrSourceElement
{
	wrName		name;
	wrLocation	pos;	// location in the source file
	wrInfoStr	info;	// short description
};


// don't change the order, it's important for comparisons
enum ESizeMode
{
	Size_Unknown = 0,
	Size_Absolute= 1,
	Size_Relative= 2,
};

// render target size
struct wrRTSize
{
	ESizeMode	sizeMode;
	union
	{
		F32	relativeSize;
		U32	absoluteSize;
		U32	sizeValue;
	};

public:
	wrRTSize()
	{
		this->sizeMode = Size_Unknown;
		this->sizeValue = 0;
	}
	void SetAbsoluteSize( UINT absoluteSize )
	{
		Assert( this->sizeMode == Size_Unknown );
		this->sizeMode = Size_Absolute;
		this->absoluteSize = absoluteSize;
	}
	void SetRelativeSize( UINT relativeSize )
	{
		Assert( this->sizeMode == Size_Unknown );
		this->sizeMode = Size_Relative;
		this->relativeSize = relativeSize;
	}

	// for sorting render targets
	friend bool operator < ( const wrRTSize& a, const wrRTSize& b )
	{
		return ( a.sizeMode < b.sizeMode );
	}
};

struct wrRenderTarget : wrSourceElement
{
	wrName		format;
	wrRTSize	sizeX, sizeY;
	FColor		clearColor;

	wrRenderTarget()
	{
		clearColor = FColor::BLACK;
	}
	static bool Compare( const wrRenderTarget& a, const wrRenderTarget& b )
	{
		return a.sizeX < b.sizeX
			&& a.sizeY < b.sizeY;
	}
};


struct wrMultiRenderTarget : wrSourceElement
{
	TList<wrRenderTarget>	renderTargets;
};

struct wrSamplerState : wrSourceElement
{
	wrName	Filter;
	wrName	AddressU, AddressV, AddressW;
};

struct wrDepthStencilState : wrSourceElement
{
	wrName DepthEnable;
	wrName DepthWriteMask;
	wrName DepthFunc;
	wrName StencilEnable;
};

struct wrRasterizerState : wrSourceElement
{
	wrName FillMode;
	wrName CullMode;
	wrName FrontCounterClockwise;
	wrName DepthBias;
	wrName DepthBiasClamp;
	wrName SlopeScaledDepthBias;
	wrName DepthClipEnable;
	wrName ScissorEnable;
	wrName MultisampleEnable;
	wrName AntialiasedLineEnable;
};

// only render target blending is supported
struct wrBlendState : wrSourceElement
{
	wrName AlphaToCoverageEnable;
	wrName BlendEnable;
	wrName SrcBlend;
	wrName DestBlend;
	wrName BlendOp;
	wrName SrcBlendAlpha;
	wrName DestBlendAlpha;
	wrName BlendOpAlpha;
	wrName RenderTargetWriteMask;
};

struct wrStateBlock : wrSourceElement
{
	// Rasterizer Stage

	wrName	rasterizerState;

	// Output-Merger Stage

	wrName	depthStencilState;
	wrName	stencilRef;

	wrName	blendState;
	FColor	blendFactorRGBA;
	wrName	sampleMask;
};


struct wrVertexElement : wrSourceElement
{
	wrName	SemanticName;
	UINT	SemanticIndex;
	wrName	Format;
	UINT	InputSlot;

	UINT	sizeInBytes;

	wrVertexElement()
	{
		SemanticIndex = -1;
		InputSlot = -1;
		sizeInBytes = 7777;
	}
};

struct wrStream
{
	TList< wrVertexElement >	elems;
};

struct wrVertexDeclaration : wrSourceElement
{
	TList< wrVertexElement >	elements;

	// names in C++ code
	TList< wrName >	elementNames;	// size == num elements
	TList< wrName >	streamNames;	// size == num streams
	TList< UINT >	streamSizes;	// size == num streams

	TList< wrStream >	streams;

	UINT	uniqueIndex;

public:
	wrVertexDeclaration()
	{
		uniqueIndex = INDEX_NONE;
	}

	UINT CalcNumStreams() const
	{
		UINT numStreams = 0;

		//BitSet32	streams(0);

		for( UINT iVertexElement = 0;
			iVertexElement < elements.Num();
			iVertexElement++ )
		{
			const wrVertexElement& elem = elements[ iVertexElement ];

			const UINT streamIndex = elem.InputSlot;

			//Assert(streams.get(streamIndex) == 0);

			//streams.set(streamIndex);

			numStreams = Max(numStreams,streamIndex+1);
		}
		return numStreams;
	}
};

enum BindFlags : U32
{
	CB_Bind_VS = BIT(0),
	CB_Bind_GS = BIT(1),
	CB_Bind_PS = BIT(2),
};

struct wrRegisterBound
{
	// Defined if the user specifies a bind point using the register keyword,
	// otherwise, INDEX_NONE
	UINT			iRegister;

	// Tells to which programmable pipeline stage (shader stages)
	// this object should be bound.
	TBits< BindFlags >		bindFlags;

	//bool	bUsed;

public:
	wrRegisterBound()
	{
		iRegister = INDEX_NONE;
		bindFlags = (BindFlags)BITS_ALL;
		//bUsed = true;
	}
	RX_OPTIMIZE("strip off unreferenced vars");
	bool isUsed() const
	{
		//return bUsed;
		return bindFlags != 0;
	}

	RX_OPTIMIZE("don't bind to slots if it's not needed");
	bool usedByVS() const
	{
		return bindFlags & CB_Bind_VS;
	}
	bool usedByGS() const
	{
		return bindFlags & CB_Bind_GS;
	}
	bool usedByPS() const
	{
		return bindFlags & CB_Bind_PS;
	}
};

// variable placed in a constant buffer
//
struct wrCBVar : wrSourceElement, wrRegisterBound
{
	wrName	typeName;

public:
	wrCBVar()
	{
	}
};

struct wrShaderConstantBuffer : wrSourceElement, wrRegisterBound
{
	TList< wrCBVar >	elements;

public:
	wrShaderConstantBuffer()
	{
	}
};

struct wrShaderSamplerState : wrSourceElement, wrRegisterBound
{
	wrName	initializer;
};

struct wrShaderResource : wrSourceElement, wrRegisterBound
{
	wrName	initializer;
};

struct wrShaderVariables
{
	TList< wrShaderConstantBuffer >	constantBuffers;
	TList< wrShaderSamplerState >	samplers;
	TList< wrShaderResource >		resources;

	BitSet32	constantBuffersSlots;
	BitSet32	samplerStatesSlots;
	BitSet32	shaderResourcesSlots;

public:
	wrShaderVariables()
		: constantBuffersSlots(0)
		, samplerStatesSlots(0)
		, shaderResourcesSlots(0)
	{
	}

	void generate_code_for_binding( TextBuffer& code ) const;
};

typedef TList< wrBuffer >	SharedSectionsList;

struct wrShaderInputs : wrShaderVariables, wrSourceElement
{
	SharedSectionsList	sharedSections;
};

struct wrShaderCode : TextBuffer
{
	wrLocation	start;
};

struct wrShaderProgram : wrSourceElement
{
	// parsed source data

	wrShaderInputs	inputs;
	wrShaderCode	code;


	wrName	vertexShader;
	wrName	pixelShader;


	// generated data

	UINT	uniqueIndex;

	TextBuffer	generatedCode;

	char* vsEntryOffset;
	UINT vsLength;

	char* psEntryOffset;
	UINT psLength;

public:
	wrShaderProgram()
	{
		uniqueIndex = INDEX_NONE;

		vsEntryOffset = nil;
		vsLength = 0;

		psEntryOffset = nil;
		psLength = 0;
	}

	UINT NumInstances() const
	{
		return 1;
	}

	bool isOk() const
	{
		return 1
			&& !pixelShader.IsEmpty()
			;
	}
};

void ParseCode( wrShaderCode & code, Parser * parser );

struct wrSharedSection : wrSourceElement
{
	// parsed data

	wrShaderVariables	vars;
	wrShaderCode		code;	// appended to shader source code

	// generated data

	TextBuffer	bindCode;	// appended to shader source code
};

struct wrSourceFile
{
	OSPathName	name;
	OSFileName	pureFileName;	// extracted file name without extension

	// render targets
	TList< wrRenderTarget >		renderTargets;

	TList< wrMultiRenderTarget >	multiRenderTargets;

	// render states
	TList< wrSamplerState >			samplerStates;
	TList< wrDepthStencilState >	depthStencilStates;
	TList< wrRasterizerState >		rasterizerStates;
	TList< wrBlendState >			blendStates;
	TList< wrStateBlock >			stateBlocks;

	// shared constants
	TList< wrSharedSection >		sharedSections;

	// shaders
	TList< wrShaderProgram >		shaders;

	// input layouts
	TList< wrVertexDeclaration >	vertexDeclarations;

public:

	wrShaderConstantBuffer & NewConstantBuffer( Parser* parser );
	wrShaderConstantBuffer & LastConstantBuffer();

	wrShaderSamplerState & NewSamplerState( Parser* parser );

	wrShaderResource& NewTexture( Parser* parser );

	wrVertexDeclaration& NewVertex( Parser* parser );

	template< class ELEMENT >
	ELEMENT & NewElement( Parser* parser, TList<ELEMENT> & elements )
	{
		ELEMENT& newOne = elements.Add();
		newOne.pos = parser->Location();
		return newOne;
	}
};



struct ParseFileInput
{
	OSPathName	pathToSrcFile;

public:
	ParseFileInput()
	{

	}
};

struct ParseFileOutput
{
	wrSourceFile	fileData;

	UINT	numErrors;
	UINT	numWarnings;

public:
	ParseFileOutput()
	{
		numErrors = 0;
		numWarnings = 0;
	}
};

struct ParseResults
{
	TList< ParseFileOutput >	parsedFiles;
};


void Translate( const Options& config, const ParseResults& input );

struct wrShaderLibrary
{
	// render targets
	TList< wrRenderTarget >			renderTargets;	// sorted by size in descending order
	TList< wrMultiRenderTarget >	multiRenderTargets;

	// render states
	TList< wrSamplerState >			samplerStates;
	TList< wrDepthStencilState >	depthStencilStates;
	TList< wrRasterizerState >		rasterizerStates;
	TList< wrBlendState >			blendStates;
	TList< wrStateBlock >			stateBlocks;

	// shared constants
	TList< wrSharedSection >		sharedSections;

	// shaders
	TList< wrShaderProgram >		shaders;	// sorted by name in ascending order

	// input layouts
	TList< wrVertexDeclaration >	vertexDeclarations;

public:
	wrShaderLibrary(const ParseResults& results);

	bool Resolve();

	wrSharedSection* FindSharedSectionByName( const char* sharedSectionName );
};







void Warning( const wrSourceElement& element, const char* fmt, ... );

//---------------------------------------------------------------------------
//	Includes
//---------------------------------------------------------------------------

#include "Parser.h"

